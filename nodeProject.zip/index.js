import express from 'express'
import puppeteer from 'puppeteer';   // Automates browser
import fetch from 'node-fetch';      // For direct API calls
import * as auth from 'node-sp-auth';
import fs from 'fs'

const app = express();
const PORT = 3000;

app.use(express.json());
const siteUrl = 'https://szgql.sharepoint.com';

// Choose your authentication method (uncomment the one you want to use)

// **1. Username/Password Authentication**
// const credentials = {
//   username: 'bibhuti@szgql.onmicrosoft.com',
//   password: 'Qipoint20192019'
// };

app.get('/', async(req, res) => {
  try {
    const browser = await puppeteer.launch({
      headless: false, // Set to true for production
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    page.setDefaultNavigationTimeout(60000);
    const loginUrl = 'https://szgql.sharepoint.com/sites/NewProject/SitePages/ECGI-POC.aspx';
    await page.goto(loginUrl, { waitUntil: 'networkidle2' });
    await new Promise((resolve) => setTimeout(resolve, 2000));
    await page.type('input[type="email"]', 'bibhuti@szgql.onmicrosoft.com');
    await page.click('input[type="submit"]');
    console.log('Email entered and "Next" clicked.');
    await new Promise((resolve) => setTimeout(resolve, 2000));
    await page.waitForSelector('input[type="password"]', { timeout: 30000 });
    await page.type('input[type="password"]', 'Qipoint20192019');
    console.log('Clicking Sign In...');
    await page.click('input[type="submit"]');
    await new Promise((resolve) => setTimeout(resolve, 3000));
    await page.click('input[type="submit"]');
    await new Promise((resolve) => setTimeout(resolve, 4000));
    const html = await page.content();
    fs.writeFileSync('epage.html', html);
    // await page.emulateMediaType('screen');

    // await page.pdf({ path: 'output.pdf', format: 'A4' });
    res.json({htmlContent:html,status:"true"})
    await browser.close();
  } catch (error) {
    console.error('Error:', error);
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
